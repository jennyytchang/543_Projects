-- CREATE TABLE nodes (
-- paperID INTEGER,
-- paperTitle VARCHAR (100));
--
-- CREATE TABLE edges (
-- paperID INTEGER,
-- citedPaperID INTEGER);

-- 2.1 Task 1 Connected Components
--   1. create undirected graph
CREATE OR ALTER VIEW undirectedGraph AS
SELECT paperID AS n1, citedPaperID AS n2 FROM edges
UNION ALL
SELECT citedPaperID AS n1, paperID AS n2 FROM edges;
GO

--   2. Run BFS
--   2.1 create table for query later
--   2.2 optimize graph
--   2.3 BFS
--   2.4 compute size 5-10
--   2.5 print

CREATE TABLE #components (
    componentID INT,
    paperID INT PRIMARY KEY
);

CREATE TABLE #visited_nodes (
    paperID INT PRIMARY KEY
);

CREATE TABLE #component_sizes (
    componentID INT,
    size INT
);
GO

-- 2.2 OPTIMIZED UNDIRECTED GRAPH VIEW
-- Add indexes to speed up joins
CREATE INDEX idx_edges_n1 ON edges(paperID);
CREATE INDEX idx_edges_n2 ON edges(citedPaperID);
GO

-- 2.3 IMPERATIVE BFS WITH PROGRESS MONITORING
DECLARE @componentID INT = 0;
DECLARE @startNode INT;
DECLARE @totalNodes INT;
DECLARE @processedNodes INT = 0;

SELECT @totalNodes = COUNT(*) FROM nodes;
PRINT 'Total nodes to process: ' + CAST(@totalNodes AS VARCHAR(20));

WHILE EXISTS (SELECT 1 FROM nodes WHERE paperID NOT IN (SELECT paperID FROM #visited_nodes))
BEGIN
    SELECT TOP 1 @startNode = paperID
    FROM nodes
    WHERE paperID NOT IN (SELECT paperID FROM #visited_nodes);

    SET @componentID = @componentID + 1;
    PRINT 'Starting new component: ' + CAST(@componentID AS VARCHAR(10))
          + ' from start node ' + CAST(@startNode AS VARCHAR(10));

    CREATE TABLE #frontier (paperID INT PRIMARY KEY);
    INSERT INTO #frontier VALUES (@startNode);
    INSERT INTO #visited_nodes VALUES (@startNode);

    WHILE EXISTS (SELECT 1 FROM #frontier)
    BEGIN
        CREATE TABLE #next (paperID INT PRIMARY KEY);

        INSERT INTO #next
        SELECT DISTINCT e.n2
        FROM #frontier f
        JOIN undirectedGraph e ON e.n1 = f.paperID
        WHERE e.n2 NOT IN (SELECT paperID FROM #visited_nodes);

        INSERT INTO #visited_nodes
        SELECT paperID FROM #next;

        INSERT INTO #components (componentID, paperID)
        SELECT @componentID, paperID
        FROM #frontier
        WHERE paperID NOT IN (SELECT paperID FROM #components);

        TRUNCATE TABLE #frontier;
        INSERT INTO #frontier
        SELECT paperID FROM #next;

        DROP TABLE #next;
    END;

    SET @processedNodes = (SELECT COUNT(*) FROM #visited_nodes);
    PRINT 'Finished component ' + CAST(@componentID AS VARCHAR(10))
          + '. Total visited so far: ' + CAST(@processedNodes AS VARCHAR(10))
          + ' / ' + CAST(@totalNodes AS VARCHAR(10));

    DROP TABLE #frontier;
END;
GO

-- 2.4 COMPUTE COMPONENT SIZES
TRUNCATE TABLE #component_sizes;

INSERT INTO #component_sizes (componentID, size)
SELECT componentID, COUNT(*) AS size
FROM #components
GROUP BY componentID;
GO

-- 2.4 COMPUTE COMPONENT SIZES
TRUNCATE TABLE #component_sizes;

INSERT INTO #component_sizes (componentID, size)
SELECT componentID, COUNT(*) AS size
FROM #components
GROUP BY componentID;
GO

-- 2.5 PRINT COMPONENTS WITH 5–10 PAPERS
PRINT '--- COMPONENTS WITH SIZE BETWEEN 5 AND 10 ---';

SELECT c.componentID AS Cluster,
       c.paperID,
       n.paperTitle
FROM #components c
JOIN #component_sizes s ON c.componentID = s.componentID
JOIN nodes n ON c.paperID = n.paperID
WHERE s.size BETWEEN 5 AND 10
ORDER BY c.componentID, c.paperID;
GO