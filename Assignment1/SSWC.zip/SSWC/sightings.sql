INSERT INTO SIGHTINGS VALUES (
	0,
	'California flannelbush',
	'Jennifer',
	'Scodie Mountains',
	'26-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	1,
	'Pale owls clover',
	'Jennifer',
	'Frog Meadows Guard Station',
	'1-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	2,
	'Draperia',
	'Jennifer',
	'Steve Spring',
	'23-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	3,
	'Sheltons violet',
	'Jennifer',
	'Covington Mountain',
	'18-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	4,
	'One-seeded pussy paws',
	'Jennifer',
	'Scodie Mountains',
	'29-May-06');


INSERT INTO SIGHTINGS VALUES (
	5,
	'Ithuriels spear',
	'Jennifer',
	'Scodie Mountains',
	'7-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	6,
	'Primrose monkeyflower',
	'Jennifer',
	'Bright Star Mine',
	'19-May-06');


INSERT INTO SIGHTINGS VALUES (
	7,
	'Yellow-and-white monkeyflower',
	'Jennifer',
	'Piute Peak',
	'18-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	8,
	'Large false Solomons seal',
	'Jennifer',
	'Piute Lookout',
	'27-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	9,
	'Showy Jacobs ladder',
	'Jennifer',
	'Grouse Meadow',
	'27-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	10,
	'Douglas dustymaiden',
	'Jennifer',
	'Burton Mill',
	'29-May-06');


INSERT INTO SIGHTINGS VALUES (
	11,
	'Varied-leaved jewelflower',
	'Jennifer',
	'Breckenridge Mountain',
	'27-May-06');


INSERT INTO SIGHTINGS VALUES (
	12,
	'Death camas',
	'Jennifer',
	'Scodie Mountains',
	'9-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	13,
	'Broad-seeded rock-cress',
	'Jennifer',
	'Double Mountain',
	'16-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	14,
	'Diamond clarkia',
	'Jennifer',
	'Puerto del Suelo',
	'20-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	15,
	'Leopard lily',
	'Jennifer',
	'Burton Mill',
	'25-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	16,
	'Torreys lomatium',
	'Jennifer',
	'Puerto del Suelo',
	'21-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	17,
	'Alpine penstemon',
	'Jennifer',
	'Scodie Mountains',
	'21-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	18,
	'Alpine sheep sorrel',
	'Jennifer',
	'Camp Alto Campground',
	'15-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	19,
	'Woodland star',
	'Jennifer',
	'Mack Meadow',
	'8-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	20,
	'Rangers buttons',
	'Jennifer',
	'Breckenridge Fire Tower',
	'18-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	21,
	'Doves-foot geranium',
	'Jennifer',
	'The George Lodge',
	'3-May-06');


INSERT INTO SIGHTINGS VALUES (
	22,
	'Globe gilia',
	'Jennifer',
	'Puerto del Suelo',
	'23-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	23,
	'Canyon dudleya',
	'Jennifer',
	'Moreland Mill',
	'12-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	24,
	'Red mountain heather',
	'Jennifer',
	'The George Lodge',
	'20-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	25,
	'Hartwegs wild ginger',
	'Jennifer',
	'Piute Lookout',
	'18-May-06');


INSERT INTO SIGHTINGS VALUES (
	26,
	'Snow plant',
	'Jennifer',
	'Scodie Mountains',
	'9-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	27,
	'Alpine lewisia',
	'Jennifer',
	'Piute Lookout',
	'25-May-06');


INSERT INTO SIGHTINGS VALUES (
	28,
	'Cow parsnip',
	'Jennifer',
	'Liebel Peak',
	'29-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	29,
	'Sierra daisy',
	'Jennifer',
	'Double Mountain',
	'12-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	30,
	'Bridges gilia',
	'Jennifer',
	'Don Levy Mine',
	'28-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	31,
	'Sierra Nevada rush',
	'Jennifer',
	'Gwynnette Mine',
	'10-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	32,
	'Purple penstemon',
	'Jennifer',
	'Piute Lookout',
	'30-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	33,
	'Mud sedge',
	'Jennifer',
	'Alaska Flat',
	'17-May-06');


INSERT INTO SIGHTINGS VALUES (
	34,
	'Showy milkweed',
	'Jennifer',
	'Sawtooth Peak',
	'18-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	35,
	'Kings sandwort',
	'Jennifer',
	'Sorrell Peak',
	'30-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	36,
	'Ithuriels spear',
	'Jennifer',
	'Double Mountain',
	'20-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	37,
	'One-seeded pussy paws',
	'Jennifer',
	'Scodie Mountains',
	'7-May-06');


INSERT INTO SIGHTINGS VALUES (
	38,
	'Alpine sheep sorrel',
	'Jennifer',
	'Scodie Mountains',
	'26-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	39,
	'Varied-leaved jewelflower',
	'Jennifer',
	'San Emigdio Mountain',
	'26-May-06');


INSERT INTO SIGHTINGS VALUES (
	40,
	'Primrose monkeyflower',
	'Jennifer',
	'Puerto del Suelo',
	'11-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	41,
	'Rangers buttons',
	'Jennifer',
	'Sorrell Peak',
	'8-May-06');


INSERT INTO SIGHTINGS VALUES (
	42,
	'Leopard lily',
	'Jennifer',
	'Piute Lookout',
	'27-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	43,
	'Torreys lomatium',
	'Jennifer',
	'Alaska Flat',
	'13-May-06');


INSERT INTO SIGHTINGS VALUES (
	44,
	'Tinkers penny',
	'Jennifer',
	'Campo Alto Campground',
	'30-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	45,
	'Sheltons violet',
	'Jennifer',
	'Burton Mill',
	'1-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	46,
	'Bridges gilia',
	'Jennifer',
	'Don Levy Mine',
	'15-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	47,
	'Broad-seeded rock-cress',
	'Jennifer',
	'Scodie Mountains',
	'26-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	48,
	'Sierra stonecrop',
	'Jennifer',
	'Alaska Flat',
	'7-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	49,
	'Death camas',
	'Jennifer',
	'Alaska Flat',
	'9-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	50,
	'Alpine penstemon',
	'Jennifer',
	'Burton Mill',
	'21-May-06');


INSERT INTO SIGHTINGS VALUES (
	51,
	'Showy Jacobs ladder',
	'Jennifer',
	'McGill Campground',
	'3-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	52,
	'Butter and eggs',
	'Jennifer',
	'Don Levy Mine',
	'29-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	53,
	'Sierra daisy',
	'Jennifer',
	'Breckenridge Fire Tower',
	'20-May-06');


INSERT INTO SIGHTINGS VALUES (
	54,
	'Douglas dustymaiden',
	'Jennifer',
	'Scodie Mountains',
	'19-May-06');


INSERT INTO SIGHTINGS VALUES (
	55,
	'Cow parsnip',
	'Jennifer',
	'Black Mountain',
	'9-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	56,
	'Pale owls clover',
	'Jennifer',
	'Alaska Flat',
	'11-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	57,
	'Woodland star',
	'Jennifer',
	'Bright Star Mine',
	'22-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	58,
	'Cow parsnip',
	'Jennifer',
	'Puerto del Suelo',
	'12-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	59,
	'Sierra stonecrop',
	'Jennifer',
	'Inspiration Point',
	'3-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	60,
	'Sheltons violet',
	'Jennifer',
	'Campo Alto Campground',
	'2-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	61,
	'Primrose monkeyflower',
	'Jennifer',
	'Mack Meadow',
	'26-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	62,
	'Broad-seeded rock-cress',
	'Jennifer',
	'Alaska Flat',
	'11-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	63,
	'Douglas dustymaiden',
	'Jennifer',
	'Black Mountain',
	'7-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	64,
	'Ithuriels spear',
	'Jennifer',
	'Frog Meadows Campground',
	'28-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	65,
	'Showy Jacobs ladder',
	'Jennifer',
	'Don Levy Mine',
	'11-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	66,
	'Death camas',
	'Jennifer',
	'Don Levy Mine',
	'24-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	67,
	'Leopard lily',
	'Jennifer',
	'Inmans',
	'23-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	68,
	'Pale owls clover',
	'Jennifer',
	'Scodie Mountains',
	'2-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	69,
	'California flannelbush',
	'Jennifer',
	'Puerto del Suelo',
	'23-May-06');


INSERT INTO SIGHTINGS VALUES (
	70,
	'Red mountain heather',
	'Jennifer',
	'Piute Lookout',
	'29-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	71,
	'Woodland star',
	'Jennifer',
	'Owens Peak',
	'17-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	72,
	'One-seeded pussy paws',
	'Jennifer',
	'Tehachapi Mountain',
	'13-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	73,
	'Alpine columbine',
	'Jennifer',
	'Bright Star Mine',
	'11-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	74,
	'Varied-leaved jewelflower',
	'Jennifer',
	'Piute Lookout',
	'9-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	75,
	'Torreys lomatium',
	'Jennifer',
	'King Solomons Ridge',
	'16-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	76,
	'Tinkers penny',
	'Jennifer',
	'Scodie Mountains',
	'3-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	77,
	'Alpine penstemon',
	'Jennifer',
	'Piute Lookout',
	'26-May-06');


INSERT INTO SIGHTINGS VALUES (
	78,
	'Large-leaved lupine',
	'Jennifer',
	'Alaska Flat',
	'18-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	79,
	'Rangers buttons',
	'Jennifer',
	'Scodie Mountains',
	'21-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	80,
	'One-sided wintergreen',
	'Jennifer',
	'Alaska Flat',
	'9-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	81,
	'Condensed phlox',
	'Jennifer',
	'Breckenridge Mountain',
	'1-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	82,
	'Doves-foot geranium',
	'Jennifer',
	'Skinner Peak',
	'25-May-06');


INSERT INTO SIGHTINGS VALUES (
	83,
	'Globe gilia',
	'Jennifer',
	'Puerto del Suelo',
	'12-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	84,
	'Diamond clarkia',
	'Jennifer',
	'Brush Mountain',
	'16-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	85,
	'Canyon dudleya',
	'Jennifer',
	'Steve Spring',
	'28-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	86,
	'Large false Solomons seal',
	'Jennifer',
	'Liebel Peak',
	'25-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	87,
	'Hartwegs wild ginger',
	'Jennifer',
	'Sorrell Peak',
	'27-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	88,
	'Alpine lewisia',
	'Jennifer',
	'Breckenridge Fire Tower',
	'29-May-06');


INSERT INTO SIGHTINGS VALUES (
	89,
	'Sierra Nevada rush',
	'Jennifer',
	'McGill Campground',
	'29-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	90,
	'Bridges gilia',
	'Jennifer',
	'Liebel Peak',
	'18-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	91,
	'Alpine sheep sorrel',
	'Jennifer',
	'Scodie Mountains',
	'1-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	92,
	'Mud sedge',
	'Jennifer',
	'Brown Peak',
	'18-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	93,
	'Alpine penstemon',
	'Jennifer',
	'Frog Meadows Guard Station',
	'22-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	94,
	'One-seeded pussy paws',
	'Jennifer',
	'Alaska Flat',
	'14-May-06');


INSERT INTO SIGHTINGS VALUES (
	95,
	'California flannelbush',
	'Jennifer',
	'Lone Star Mine',
	'9-May-06');


INSERT INTO SIGHTINGS VALUES (
	96,
	'Canyon dudleya',
	'Jennifer',
	'Breckenridge Mountain',
	'3-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	97,
	'Broad-seeded rock-cress',
	'Jennifer',
	'Burton Mill',
	'28-May-06');


INSERT INTO SIGHTINGS VALUES (
	98,
	'Woodland star',
	'Jennifer',
	'Scodie Mountains',
	'14-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	99,
	'Rangers buttons',
	'Jennifer',
	'Bright Star Mine',
	'22-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	100,
	'Butter and eggs',
	'Jennifer',
	'Piute Lookout',
	'15-May-06');


INSERT INTO SIGHTINGS VALUES (
	101,
	'Showy Jacobs ladder',
	'Jennifer',
	'Scodie Mountains',
	'8-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	102,
	'Ithuriels spear',
	'Jennifer',
	'Covington Mountain',
	'17-May-06');


INSERT INTO SIGHTINGS VALUES (
	103,
	'Primrose monkeyflower',
	'Jennifer',
	'Steve Spring',
	'1-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	104,
	'Sheltons violet',
	'Jennifer',
	'Piute Lookout',
	'21-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	105,
	'Douglas dustymaiden',
	'Jennifer',
	'Grouse Meadow',
	'6-May-06');


INSERT INTO SIGHTINGS VALUES (
	106,
	'Pale owls clover',
	'Jennifer',
	'Don Levy Mine',
	'15-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	107,
	'Torreys lomatium',
	'Jennifer',
	'Liebel Peak',
	'19-May-06');


INSERT INTO SIGHTINGS VALUES (
	108,
	'Death camas',
	'Jennifer',
	'Piute Lookout',
	'7-May-06');


INSERT INTO SIGHTINGS VALUES (
	109,
	'Alpine sheep sorrel',
	'Jennifer',
	'Chula Vista Campground',
	'20-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	110,
	'Varied-leaved jewelflower',
	'Jennifer',
	'Burton Mill',
	'8-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	111,
	'Leopard lily',
	'Jennifer',
	'Scodie Mountains',
	'4-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	112,
	'Doves-foot geranium',
	'Jennifer',
	'Tehachapi Mountain',
	'10-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	113,
	'Globe gilia',
	'Jennifer',
	'King Solomons Ridge',
	'14-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	114,
	'Large false Solomons seal',
	'Jennifer',
	'Breckenridge Fire Tower',
	'10-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	115,
	'Hartwegs wild ginger',
	'Jennifer',
	'Cerro Noroeste',
	'4-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	116,
	'Alpine lewisia',
	'Jennifer',
	'Puerto del Suelo',
	'25-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	117,
	'Cow parsnip',
	'Jennifer',
	'Breckenridge Mountain',
	'1-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	118,
	'Bridges gilia',
	'Jennifer',
	'Bright Star Mine',
	'23-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	119,
	'Purple penstemon',
	'Jennifer',
	'Scodie Mountains',
	'22-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	120,
	'Sierra angelica',
	'Jennifer',
	'Covington Mountain',
	'22-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	121,
	'Sierra Nevada rush',
	'Jennifer',
	'Sawtooth Peak',
	'13-May-06');


INSERT INTO SIGHTINGS VALUES (
	122,
	'Mud sedge',
	'Jennifer',
	'Sorrell Peak',
	'20-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	123,
	'Draperia',
	'Jennifer',
	'Mount Jenkins',
	'3-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	124,
	'Showy milkweed',
	'Jennifer',
	'Scodie Mountains',
	'12-May-06');


INSERT INTO SIGHTINGS VALUES (
	125,
	'Sierra stonecrop',
	'Jennifer',
	'King Solomons Ridge',
	'21-May-06');


INSERT INTO SIGHTINGS VALUES (
	126,
	'Hoary buckwheat',
	'Jennifer',
	'Scodie Mountains',
	'12-May-06');


INSERT INTO SIGHTINGS VALUES (
	127,
	'Ithuriels spear',
	'Jennifer',
	'Scodie Mountains',
	'3-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	128,
	'Bridges gilia',
	'Maria',
	'Chula Vista Campground',
	'26-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	129,
	'Oak violet',
	'Maria',
	'Don Levy Mine',
	'1-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	130,
	'California flannelbush',
	'Maria',
	'Scodie Mountains',
	'2-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	131,
	'Condensed phlox',
	'Maria',
	'Sawtooth Peak',
	'7-May-06');


INSERT INTO SIGHTINGS VALUES (
	132,
	'Douglas dustymaiden',
	'Maria',
	'Piute Lookout',
	'11-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	133,
	'Pale owls clover',
	'Maria',
	'Covington Mountain',
	'28-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	134,
	'Diamond clarkia',
	'Maria',
	'Cerro Noroeste',
	'16-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	135,
	'Primrose monkeyflower',
	'Maria',
	'Double Mountain',
	'10-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	136,
	'Sheltons violet',
	'Maria',
	'Campo Alto Campground',
	'1-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	137,
	'Showy Jacobs ladder',
	'Maria',
	'Inmans',
	'2-May-06');


INSERT INTO SIGHTINGS VALUES (
	138,
	'Death camas',
	'Maria',
	'Scodie Mountains',
	'4-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	139,
	'Broad-seeded rock-cress',
	'Maria',
	'Tehachapi Mountain',
	'17-May-06');


INSERT INTO SIGHTINGS VALUES (
	140,
	'Woodland star',
	'Maria',
	'Cerro Noroeste',
	'12-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	141,
	'One-seeded pussy paws',
	'Maria',
	'Double Mountain',
	'14-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	142,
	'Varied-leaved jewelflower',
	'Maria',
	'Scodie Mountains',
	'4-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	143,
	'Cow parsnip',
	'Maria',
	'Puerto del Suelo',
	'14-May-06');


INSERT INTO SIGHTINGS VALUES (
	144,
	'Leopard lily',
	'Maria',
	'Chula Vista Campground',
	'14-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	145,
	'Torreys lomatium',
	'Maria',
	'Piute Peak',
	'15-May-06');


INSERT INTO SIGHTINGS VALUES (
	146,
	'Alpine penstemon',
	'Maria',
	'Mack Meadow',
	'13-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	147,
	'Rangers buttons',
	'Maria',
	'Moreland Mill',
	'22-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	148,
	'Doves-foot geranium',
	'Maria',
	'Alaska Flat',
	'17-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	149,
	'Globe gilia',
	'Maria',
	'Liebel Peak',
	'14-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	150,
	'Canyon dudleya',
	'Maria',
	'Frog Meadows Campground',
	'6-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	151,
	'Large false Solomons seal',
	'Maria',
	'Scodie Mountains',
	'20-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	152,
	'Hartwegs wild ginger',
	'Maria',
	'Lone Star Mine',
	'16-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	153,
	'Alpine lewisia',
	'Maria',
	'Alaska Flat',
	'16-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	154,
	'Alpine sheep sorrel',
	'Maria',
	'Scodie Mountains',
	'23-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	155,
	'Sierra Nevada rush',
	'Maria',
	'Alaska Flat',
	'1-May-06');


INSERT INTO SIGHTINGS VALUES (
	156,
	'Mud sedge',
	'Maria',
	'Piute Peak',
	'26-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	157,
	'Draperia',
	'Maria',
	'Scodie Mountains',
	'11-May-06');


INSERT INTO SIGHTINGS VALUES (
	158,
	'Showy milkweed',
	'Maria',
	'Cerro Noroeste',
	'11-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	159,
	'Butter and eggs',
	'Maria',
	'Scodie Mountains',
	'6-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	160,
	'Snow plant',
	'Maria',
	'Piute Lookout',
	'10-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	161,
	'Sierra stonecrop',
	'Maria',
	'Scodie Mountains',
	'30-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	162,
	'Sierra daisy',
	'Maria',
	'Alaska Flat',
	'16-May-06');


INSERT INTO SIGHTINGS VALUES (
	163,
	'Large-leaved lupine',
	'Maria',
	'Piute Lookout',
	'3-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	164,
	'Hoary buckwheat',
	'Maria',
	'Puerto del Suelo',
	'24-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	165,
	'Sierra angelica',
	'Maria',
	'Grouse Meadow',
	'19-May-06');


INSERT INTO SIGHTINGS VALUES (
	166,
	'Alpine columbine',
	'Maria',
	'Chula Vista Campground',
	'28-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	167,
	'Water groundsel',
	'Maria',
	'Piute Lookout',
	'19-May-06');


INSERT INTO SIGHTINGS VALUES (
	168,
	'Kings sandwort',
	'Maria',
	'Don Levy Mine',
	'1-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	169,
	'Woolly sunflower',
	'Maria',
	'Don Levy Mine',
	'23-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	170,
	'One-sided wintergreen',
	'Maria',
	'Frog Meadows Campground',
	'11-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	171,
	'Red mountain heather',
	'Maria',
	'Puerto del Suelo',
	'14-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	172,
	'Purple penstemon',
	'Maria',
	'Bright Star Mine',
	'23-May-06');


INSERT INTO SIGHTINGS VALUES (
	173,
	'Fireweed',
	'Maria',
	'Cerro Noroeste',
	'29-May-06');


INSERT INTO SIGHTINGS VALUES (
	174,
	'Tinkers penny',
	'Maria',
	'Scodie Mountains',
	'14-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	175,
	'Yellow-and-white monkeyflower',
	'Maria',
	'Burton Mill',
	'7-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	176,
	'Lovage',
	'Maria',
	'Burton Mill',
	'14-May-06');


INSERT INTO SIGHTINGS VALUES (
	177,
	'Broad-seeded rock-cress',
	'Maria',
	'Cerro Noroeste',
	'2-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	178,
	'Primrose monkeyflower',
	'Maria',
	'Don Levy Mine',
	'12-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	179,
	'Cow parsnip',
	'Maria',
	'Scodie Mountains',
	'5-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	180,
	'Ithuriels spear',
	'Maria',
	'Burton Mill',
	'26-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	181,
	'Death camas',
	'Maria',
	'Inspiration Point',
	'7-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	182,
	'Sierra stonecrop',
	'Maria',
	'Inspiration Point',
	'16-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	183,
	'Sheltons violet',
	'Maria',
	'KBAK-TV',
	'6-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	184,
	'Pale owls clover',
	'Maria',
	'Scodie Mountains',
	'12-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	185,
	'Showy Jacobs ladder',
	'Maria',
	'Burton Mill',
	'22-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	186,
	'Showy milkweed',
	'Maria',
	'Piute Lookout',
	'30-May-06');


INSERT INTO SIGHTINGS VALUES (
	187,
	'Oak violet',
	'Maria',
	'Steve Spring',
	'28-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	188,
	'Douglas dustymaiden',
	'Maria',
	'Burton Mill',
	'14-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	189,
	'Canyon dudleya',
	'Maria',
	'Sawtooth Peak',
	'8-May-06');


INSERT INTO SIGHTINGS VALUES (
	190,
	'One-seeded pussy paws',
	'Maria',
	'The George Lodge',
	'21-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	191,
	'Varied-leaved jewelflower',
	'Maria',
	'Covington Mountain',
	'16-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	192,
	'Woodland star',
	'Maria',
	'Liebel Peak',
	'8-May-06');


INSERT INTO SIGHTINGS VALUES (
	193,
	'Leopard lily',
	'Maria',
	'Scodie Mountains',
	'2-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	194,
	'Bridges gilia',
	'Maria',
	'Don Levy Mine',
	'18-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	195,
	'Torreys lomatium',
	'Maria',
	'Piute Peak',
	'5-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	196,
	'Alpine penstemon',
	'Maria',
	'Inspiration Point',
	'16-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	197,
	'Rangers buttons',
	'Maria',
	'Alaska Flat',
	'11-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	198,
	'Doves-foot geranium',
	'Maria',
	'Chula Vista Campground',
	'6-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	199,
	'Butter and eggs',
	'Maria',
	'Scodie Mountains',
	'20-May-06');


INSERT INTO SIGHTINGS VALUES (
	200,
	'Globe gilia',
	'Maria',
	'Moreland Mill',
	'1-May-06');


INSERT INTO SIGHTINGS VALUES (
	201,
	'Large false Solomons seal',
	'Maria',
	'Brown Meadow',
	'10-May-06');


INSERT INTO SIGHTINGS VALUES (
	202,
	'Hoary buckwheat',
	'Maria',
	'Scodie Mountains',
	'26-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	203,
	'Sheltons violet',
	'Michael',
	'Scodie Mountains',
	'26-May-06');


INSERT INTO SIGHTINGS VALUES (
	204,
	'Leopard lily',
	'Michael',
	'Alaska Flat',
	'4-May-06');


INSERT INTO SIGHTINGS VALUES (
	205,
	'Douglas dustymaiden',
	'Michael',
	'Bright Star Mine',
	'12-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	206,
	'Ithuriels spear',
	'Michael',
	'Scodie Mountains',
	'5-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	207,
	'Sheltons violet',
	'Michael',
	'Scodie Mountains',
	'1-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	208,
	'Primrose monkeyflower',
	'Michael',
	'Water Gap Spring',
	'7-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	209,
	'Butter and eggs',
	'Michael',
	'Burton Mill',
	'21-May-06');


INSERT INTO SIGHTINGS VALUES (
	210,
	'California flannelbush',
	'Michael',
	'Camp Mountain Meadows',
	'7-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	211,
	'Ithuriels spear',
	'Michael',
	'Piute Lookout',
	'25-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	212,
	'Kings sandwort',
	'Michael',
	'Morris Peak',
	'8-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	213,
	'Sheltons violet',
	'Michael',
	'Owens Peak',
	'16-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	214,
	'Oak violet',
	'Michael',
	'Cerro Noroeste',
	'22-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	215,
	'Canyon dudleya',
	'Michael',
	'Alaska Flat',
	'13-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	216,
	'Alpine penstemon',
	'Michael',
	'Scodie Mountains',
	'25-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	217,
	'Cow parsnip',
	'Michael',
	'Lone Star Mine',
	'22-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	218,
	'Showy Jacobs ladder',
	'Michael',
	'The George Lodge',
	'12-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	219,
	'Pale owls clover',
	'Michael',
	'Scodie Mountains',
	'24-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	220,
	'Showy milkweed',
	'Michael',
	'Brown Peak',
	'19-May-06');


INSERT INTO SIGHTINGS VALUES (
	221,
	'Douglas dustymaiden',
	'Michael',
	'Brown Peak',
	'20-May-06');


INSERT INTO SIGHTINGS VALUES (
	222,
	'Showy Jacobs ladder',
	'Michael',
	'Scodie Mountains',
	'24-May-06');


INSERT INTO SIGHTINGS VALUES (
	223,
	'Primrose monkeyflower',
	'Michael',
	'Alaska Flat',
	'20-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	224,
	'Sheltons violet',
	'Michael',
	'Double Mountain',
	'27-May-06');


INSERT INTO SIGHTINGS VALUES (
	225,
	'Globe gilia',
	'Michael',
	'Skinner Peak',
	'20-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	226,
	'California flannelbush',
	'Michael',
	'Don Levy Mine',
	'14-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	227,
	'Ithuriels spear',
	'Michael',
	'Tecuya Mountain',
	'2-May-06');


INSERT INTO SIGHTINGS VALUES (
	228,
	'Canyon dudleya',
	'Michael',
	'Frog Meadows Campground',
	'16-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	229,
	'Sheltons violet',
	'Michael',
	'Puerto del Suelo',
	'22-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	230,
	'Varied-leaved jewelflower',
	'Michael',
	'Sorrell Peak',
	'28-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	231,
	'Showy milkweed',
	'Michael',
	'Scodie Mountains',
	'22-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	232,
	'Sierra stonecrop',
	'Michael',
	'Alaska Flat',
	'4-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	233,
	'Ithuriels spear',
	'Michael',
	'Alaska Flat',
	'28-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	234,
	'Sheltons violet',
	'Michael',
	'Piute Lookout',
	'16-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	235,
	'California flannelbush',
	'Michael',
	'Burton Mill',
	'24-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	236,
	'Leopard lily',
	'Michael',
	'Puerto del Suelo',
	'7-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	237,
	'Pale owls clover',
	'Michael',
	'Morris Peak',
	'29-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	238,
	'Broad-seeded rock-cress',
	'Michael',
	'McGill Campground',
	'11-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	239,
	'Leopard lily',
	'Michael',
	'Owens Peak',
	'5-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	240,
	'Alpine penstemon',
	'Michael',
	'Inmans',
	'1-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	241,
	'Sheltons violet',
	'Michael',
	'McGill Campground',
	'21-May-06');


INSERT INTO SIGHTINGS VALUES (
	242,
	'Sheltons violet',
	'Michael',
	'Puerto del Suelo',
	'4-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	243,
	'Primrose monkeyflower',
	'Michael',
	'Scodie Mountains',
	'24-May-06');


INSERT INTO SIGHTINGS VALUES (
	244,
	'Showy Jacobs ladder',
	'Michael',
	'Alaska Flat',
	'8-May-06');


INSERT INTO SIGHTINGS VALUES (
	245,
	'California flannelbush',
	'Michael',
	'Breckenridge Mountain',
	'22-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	246,
	'Ithuriels spear',
	'Michael',
	'Scodie Mountains',
	'21-May-06');


INSERT INTO SIGHTINGS VALUES (
	247,
	'Large-leaved lupine',
	'Michael',
	'Inspiration Point',
	'23-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	248,
	'California flannelbush',
	'Michael',
	'KBAK-TV',
	'20-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	249,
	'Varied-leaved jewelflower',
	'Michael',
	'Alaska Flat',
	'10-May-06');


INSERT INTO SIGHTINGS VALUES (
	250,
	'California flannelbush',
	'Helen',
	'Scodie Mountains',
	'13-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	251,
	'Woodland star',
	'Helen',
	'Cold Spring',
	'19-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	252,
	'Sierra Nevada rush',
	'Helen',
	'Cold Spring',
	'24-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	253,
	'Ithuriels spear',
	'Helen',
	'Cold Spring',
	'3-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	254,
	'Primrose monkeyflower',
	'Helen',
	'Scodie Mountains',
	'5-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	255,
	'Fireweed',
	'Helen',
	'Liebel Peak',
	'11-May-06');


INSERT INTO SIGHTINGS VALUES (
	256,
	'Varied-leaved jewelflower',
	'Helen',
	'Scodie Mountains',
	'26-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	257,
	'Sheltons violet',
	'Helen',
	'Covington Mountain',
	'29-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	258,
	'Kings sandwort',
	'Helen',
	'Alaska Flat',
	'5-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	259,
	'Alpine penstemon',
	'Helen',
	'Alaska Flat',
	'30-May-06');


INSERT INTO SIGHTINGS VALUES (
	260,
	'Showy Jacobs ladder',
	'Helen',
	'Bright Star Mine',
	'25-May-06');


INSERT INTO SIGHTINGS VALUES (
	261,
	'Torreys lomatium',
	'Helen',
	'Liebel Peak',
	'26-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	262,
	'Condensed phlox',
	'Helen',
	'Covington Mountain',
	'19-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	263,
	'Sheltons violet',
	'Helen',
	'Alaska Flat',
	'8-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	264,
	'One-seeded pussy paws',
	'Helen',
	'Bright Star Mine',
	'28-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	265,
	'Death camas',
	'Helen',
	'Liebel Peak',
	'11-May-06');


INSERT INTO SIGHTINGS VALUES (
	266,
	'Primrose monkeyflower',
	'Helen',
	'Alaska Flat',
	'25-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	267,
	'Ithuriels spear',
	'Helen',
	'Don Levy Mine',
	'7-May-06');


INSERT INTO SIGHTINGS VALUES (
	268,
	'California flannelbush',
	'Helen',
	'Breckenridge Fire Tower',
	'26-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	269,
	'Kings sandwort',
	'Helen',
	'Piute Lookout',
	'20-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	270,
	'Cow parsnip',
	'Helen',
	'Bright Star Mine',
	'27-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	271,
	'Showy Jacobs ladder',
	'Helen',
	'Campo Alto Campground',
	'25-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	272,
	'Douglas dustymaiden',
	'Helen',
	'Bright Star Mine',
	'23-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	273,
	'Showy milkweed',
	'Helen',
	'Sorrell Peak',
	'13-May-06');


INSERT INTO SIGHTINGS VALUES (
	274,
	'Canyon dudleya',
	'Helen',
	'Alaska Flat',
	'8-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	275,
	'Pale owls clover',
	'Helen',
	'Piute Lookout',
	'18-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	276,
	'Broad-seeded rock-cress',
	'Helen',
	'Scodie Mountains',
	'22-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	277,
	'Varied-leaved jewelflower',
	'Helen',
	'King Solomons Ridge',
	'5-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	278,
	'Leopard lily',
	'Helen',
	'Bright Star Mine',
	'13-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	279,
	'Torreys lomatium',
	'Helen',
	'Piute Lookout',
	'6-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	280,
	'Yellow-and-white monkeyflower',
	'Helen',
	'Burton Mill',
	'17-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	281,
	'Alpine penstemon',
	'Helen',
	'Puerto del Suelo',
	'6-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	282,
	'Woodland star',
	'Helen',
	'Water Gap Spring',
	'30-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	283,
	'Rangers buttons',
	'Helen',
	'Piute Peak',
	'13-May-06');


INSERT INTO SIGHTINGS VALUES (
	284,
	'Doves-foot geranium',
	'Helen',
	'Piute Lookout',
	'7-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	285,
	'Large-leaved lupine',
	'Helen',
	'Bright Star Mine',
	'30-May-06');


INSERT INTO SIGHTINGS VALUES (
	286,
	'Globe gilia',
	'Helen',
	'The George Lodge',
	'4-May-06');


INSERT INTO SIGHTINGS VALUES (
	287,
	'Large false Solomons seal',
	'Helen',
	'Grouse Mountain',
	'21-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	288,
	'Hartwegs wild ginger',
	'Helen',
	'Bright Star Mine',
	'5-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	289,
	'One-sided wintergreen',
	'Helen',
	'Black Mountain',
	'2-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	290,
	'Alpine lewisia',
	'Helen',
	'Bright Star Mine',
	'20-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	291,
	'Bridges gilia',
	'Helen',
	'Breckenridge Fire Tower',
	'3-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	292,
	'Alpine sheep sorrel',
	'Helen',
	'Scodie Mountains',
	'1-May-06');


INSERT INTO SIGHTINGS VALUES (
	293,
	'Sierra Nevada rush',
	'Sandra',
	'Piute Lookout',
	'4-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	294,
	'California flannelbush',
	'Sandra',
	'Bright Star Mine',
	'2-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	295,
	'Primrose monkeyflower',
	'Sandra',
	'Brown Meadow',
	'20-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	296,
	'Oak violet',
	'Sandra',
	'Inspiration Point',
	'19-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	297,
	'Sheltons violet',
	'Sandra',
	'Piute Lookout',
	'27-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	298,
	'Rangers buttons',
	'Sandra',
	'Owens Peak',
	'2-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	299,
	'Alpine lewisia',
	'Sandra',
	'Scodie Mountains',
	'9-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	300,
	'California flannelbush',
	'Sandra',
	'Bright Star Mine',
	'30-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	301,
	'Douglas dustymaiden',
	'Sandra',
	'Inspiration Point',
	'3-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	302,
	'Primrose monkeyflower',
	'Sandra',
	'Puerto del Suelo',
	'3-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	303,
	'Leopard lily',
	'Sandra',
	'Alaska Flat',
	'13-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	304,
	'One-seeded pussy paws',
	'Sandra',
	'Sorrell Peak',
	'23-May-06');


INSERT INTO SIGHTINGS VALUES (
	305,
	'Pale owls clover',
	'Sandra',
	'Piute Lookout',
	'1-May-06');


INSERT INTO SIGHTINGS VALUES (
	306,
	'Alpine lewisia',
	'Sandra',
	'Chula Vista Campground',
	'19-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	307,
	'Douglas dustymaiden',
	'Sandra',
	'Gwynnette Mine',
	'9-May-06');


INSERT INTO SIGHTINGS VALUES (
	308,
	'Ithuriels spear',
	'Sandra',
	'Chula Vista Campground',
	'2-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	309,
	'Primrose monkeyflower',
	'Sandra',
	'Liebel Peak',
	'27-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	310,
	'Snow plant',
	'Sandra',
	'Scodie Mountains',
	'8-May-06');


INSERT INTO SIGHTINGS VALUES (
	311,
	'Ithuriels spear',
	'Sandra',
	'Scodie Mountains',
	'14-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	312,
	'Varied-leaved jewelflower',
	'Sandra',
	'Inspiration Point',
	'8-May-06');


INSERT INTO SIGHTINGS VALUES (
	313,
	'California flannelbush',
	'Sandra',
	'San Emigdio Mountain',
	'29-May-06');


INSERT INTO SIGHTINGS VALUES (
	314,
	'Primrose monkeyflower',
	'Sandra',
	'Grouse Mountain',
	'29-May-06');


INSERT INTO SIGHTINGS VALUES (
	315,
	'Canyon dudleya',
	'Sandra',
	'Brown Meadow',
	'6-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	316,
	'Alpine lewisia',
	'Sandra',
	'Covington Mountain',
	'10-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	317,
	'Ithuriels spear',
	'Sandra',
	'Puerto del Suelo',
	'29-May-06');


INSERT INTO SIGHTINGS VALUES (
	318,
	'Doves-foot geranium',
	'Sandra',
	'Breckenridge Fire Tower',
	'23-May-06');


INSERT INTO SIGHTINGS VALUES (
	319,
	'Alpine columbine',
	'Donna',
	'Chula Vista Campground',
	'3-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	320,
	'California flannelbush',
	'Donna',
	'Piute Lookout',
	'1-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	321,
	'Pale owls clover',
	'Donna',
	'San Emigdio Mountain',
	'20-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	322,
	'Ithuriels spear',
	'Donna',
	'Piute Lookout',
	'30-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	323,
	'Primrose monkeyflower',
	'Donna',
	'Breckenridge Mountain',
	'23-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	324,
	'Kings sandwort',
	'Donna',
	'Frog Meadows Campground',
	'27-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	325,
	'Sheltons violet',
	'Donna',
	'Piute Lookout',
	'24-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	326,
	'Sierra angelica',
	'Donna',
	'Puerto del Suelo',
	'16-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	327,
	'Alpine sheep sorrel',
	'Donna',
	'Sorrell Peak',
	'16-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	328,
	'Showy Jacobs ladder',
	'Donna',
	'Skinner Peak',
	'13-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	329,
	'Cow parsnip',
	'Donna',
	'Alaska Flat',
	'21-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	330,
	'Doves-foot geranium',
	'Donna',
	'Puerto del Suelo',
	'8-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	331,
	'Ithuriels spear',
	'Donna',
	'Piute Lookout',
	'4-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	332,
	'Globe gilia',
	'Donna',
	'Scodie Mountains',
	'14-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	333,
	'Primrose monkeyflower',
	'Donna',
	'Tecuya Mountain',
	'19-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	334,
	'California flannelbush',
	'Donna',
	'Scodie Mountains',
	'21-May-06');


INSERT INTO SIGHTINGS VALUES (
	335,
	'Broad-seeded rock-cress',
	'Donna',
	'Piute Lookout',
	'16-May-06');


INSERT INTO SIGHTINGS VALUES (
	336,
	'Death camas',
	'Donna',
	'Don Levy Mine',
	'11-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	337,
	'Rangers buttons',
	'Donna',
	'Double Mountain',
	'7-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	338,
	'Sierra stonecrop',
	'Donna',
	'Double Mountain',
	'1-May-06');


INSERT INTO SIGHTINGS VALUES (
	339,
	'Sheltons violet',
	'Donna',
	'Don Levy Mine',
	'18-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	340,
	'Sierra Nevada rush',
	'Donna',
	'Sorrell Peak',
	'20-May-06');


INSERT INTO SIGHTINGS VALUES (
	341,
	'Showy Jacobs ladder',
	'Donna',
	'Scodie Mountains',
	'19-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	342,
	'Alpine penstemon',
	'James',
	'Piute Lookout',
	'7-May-06');


INSERT INTO SIGHTINGS VALUES (
	343,
	'Showy Jacobs ladder',
	'James',
	'Don Levy Mine',
	'24-May-06');


INSERT INTO SIGHTINGS VALUES (
	344,
	'Condensed phlox',
	'James',
	'Morris Peak',
	'10-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	345,
	'Ithuriels spear',
	'James',
	'Camp Mountain Meadows',
	'4-May-06');


INSERT INTO SIGHTINGS VALUES (
	346,
	'Primrose monkeyflower',
	'James',
	'Cerro Noroeste',
	'30-May-06');


INSERT INTO SIGHTINGS VALUES (
	347,
	'Sheltons violet',
	'James',
	'Bright Star Mine',
	'26-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	348,
	'California flannelbush',
	'James',
	'Frog Meadows Campground',
	'19-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	349,
	'Douglas dustymaiden',
	'James',
	'Burton Mill',
	'27-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	350,
	'One-seeded pussy paws',
	'James',
	'Don Levy Mine',
	'17-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	351,
	'Pale owls clover',
	'James',
	'Scodie Mountains',
	'12-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	352,
	'Death camas',
	'James',
	'The George Lodge',
	'30-May-06');


INSERT INTO SIGHTINGS VALUES (
	353,
	'Broad-seeded rock-cress',
	'James',
	'Piute Spring',
	'13-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	354,
	'Canyon dudleya',
	'James',
	'Piute Peak',
	'12-May-06');


INSERT INTO SIGHTINGS VALUES (
	355,
	'Varied-leaved jewelflower',
	'James',
	'Double Mountain',
	'14-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	356,
	'Hoary buckwheat',
	'James',
	'King Solomons Ridge',
	'2-May-06');


INSERT INTO SIGHTINGS VALUES (
	357,
	'Purple penstemon',
	'James',
	'Puerto del Suelo',
	'2-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	358,
	'Large false Solomons seal',
	'James',
	'Owens Peak',
	'28-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	359,
	'Leopard lily',
	'James',
	'Don Levy Mine',
	'23-May-06');


INSERT INTO SIGHTINGS VALUES (
	360,
	'Sierra daisy',
	'James',
	'Cold Spring',
	'7-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	361,
	'Torreys lomatium',
	'James',
	'Piute Lookout',
	'6-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	362,
	'Woodland star',
	'James',
	'Piute Lookout',
	'24-Apr-06');


INSERT INTO SIGHTINGS VALUES (
	363,
	'Rangers buttons',
	'James',
	'Black Mountain',
	'10-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	364,
	'Death camas',
	'John',
	'Burton Mill',
	'21-May-06');


INSERT INTO SIGHTINGS VALUES (
	365,
	'California flannelbush',
	'John',
	'Owens Peak',
	'4-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	366,
	'Showy Jacobs ladder',
	'John',
	'Alaska Flat',
	'2-May-06');


INSERT INTO SIGHTINGS VALUES (
	367,
	'Sierra Nevada rush',
	'John',
	'Scodie Mountains',
	'22-May-06');


INSERT INTO SIGHTINGS VALUES (
	368,
	'Douglas dustymaiden',
	'John',
	'Owens Peak',
	'12-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	369,
	'California flannelbush',
	'John',
	'Piute Lookout',
	'19-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	370,
	'Primrose monkeyflower',
	'John',
	'Gwynnette Mine',
	'29-May-06');


INSERT INTO SIGHTINGS VALUES (
	371,
	'Broad-seeded rock-cress',
	'John',
	'Bright Star Mine',
	'24-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	372,
	'Ithuriels spear',
	'John',
	'Owens Peak',
	'22-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	373,
	'One-seeded pussy paws',
	'John',
	'Don Levy Mine',
	'8-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	374,
	'California flannelbush',
	'John',
	'Piute Lookout',
	'16-May-06');


INSERT INTO SIGHTINGS VALUES (
	375,
	'California flannelbush',
	'John',
	'Piute Lookout',
	'11-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	376,
	'Ithuriels spear',
	'John',
	'Scodie Mountains',
	'17-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	377,
	'Sierra daisy',
	'John',
	'Piute Lookout',
	'24-Aug-06');


INSERT INTO SIGHTINGS VALUES (
	378,
	'Primrose monkeyflower',
	'John',
	'Mount Jenkins',
	'5-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	379,
	'Sheltons violet',
	'John',
	'Don Levy Mine',
	'23-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	380,
	'California flannelbush',
	'Robert',
	'Don Levy Mine',
	'4-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	381,
	'Red mountain heather',
	'Robert',
	'Alaska Flat',
	'7-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	382,
	'Torreys lomatium',
	'Robert',
	'Scodie Mountains',
	'2-Sep-06');


INSERT INTO SIGHTINGS VALUES (
	383,
	'Death camas',
	'Robert',
	'Piute Lookout',
	'28-May-06');


INSERT INTO SIGHTINGS VALUES (
	384,
	'Ithuriels spear',
	'Robert',
	'Alaska Flat',
	'23-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	385,
	'Hoary buckwheat',
	'Robert',
	'Black Mountain',
	'18-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	386,
	'Torreys lomatium',
	'Robert',
	'Liebel Peak',
	'21-May-06');


INSERT INTO SIGHTINGS VALUES (
	387,
	'Showy Jacobs ladder',
	'Robert',
	'Owens Peak',
	'21-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	388,
	'Large-leaved lupine',
	'Robert',
	'Lone Star Mine',
	'10-May-06');


INSERT INTO SIGHTINGS VALUES (
	389,
	'California flannelbush',
	'Robert',
	'Cerro Noroeste',
	'1-May-06');


INSERT INTO SIGHTINGS VALUES (
	390,
	'Pale owls clover',
	'Robert',
	'Breckenridge Fire Tower',
	'19-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	391,
	'Hartwegs wild ginger',
	'Robert',
	'Brown Peak',
	'12-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	392,
	'Varied-leaved jewelflower',
	'Robert',
	'Piute Lookout',
	'3-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	393,
	'Sheltons violet',
	'Robert',
	'Scodie Mountains',
	'13-May-06');


INSERT INTO SIGHTINGS VALUES (
	394,
	'California flannelbush',
	'Robert',
	'The George Lodge',
	'22-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	395,
	'Large false Solomons seal',
	'Michael',
	'Cold Spring',
	'29-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	396,
	'Sheltons violet',
	'Michael',
	'Piute Spring',
	'5-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	397,
	'California flannelbush',
	'Michael',
	'Scodie Mountains',
	'10-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	398,
	'Douglas dustymaiden',
	'Michael',
	'Chula Vista Campground',
	'9-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	399,
	'Ithuriels spear',
	'Michael',
	'Grouse Mountain',
	'4-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	400,
	'Butter and eggs',
	'Michael',
	'Scodie Mountains',
	'13-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	401,
	'Death camas',
	'Michael',
	'Don Levy Mine',
	'4-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	402,
	'Pale owls clover',
	'Michael',
	'Sorrell Peak',
	'4-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	403,
	'Rangers buttons',
	'Michael',
	'Scodie Mountains',
	'27-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	404,
	'Draperia',
	'Michael',
	'Mount Jenkins',
	'8-May-06');


INSERT INTO SIGHTINGS VALUES (
	405,
	'Leopard lily',
	'Michael',
	'Chula Vista Campground',
	'22-May-06');


INSERT INTO SIGHTINGS VALUES (
	406,
	'California flannelbush',
	'Michael',
	'Camp Mountain Meadows',
	'28-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	407,
	'Large false Solomons seal',
	'Tim',
	'Cold Spring',
	'29-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	408,
	'Sheltons violet',
	'Tim',
	'Piute Spring',
	'5-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	409,
	'California flannelbush',
	'Tim',
	'Scodie Mountains',
	'10-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	410,
	'Douglas dustymaiden',
	'Tim',
	'Chula Vista Campground',
	'9-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	411,
	'Ithuriels spear',
	'Tim',
	'Grouse Mountain',
	'4-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	412,
	'Butter and eggs',
	'Tim',
	'Scodie Mountains',
	'13-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	413,
	'Death camas',
	'Tim',
	'Don Levy Mine',
	'4-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	414,
	'Pale owls clover',
	'Tim',
	'Sorrell Peak',
	'4-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	415,
	'Rangers buttons',
	'Tim',
	'Scodie Mountains',
	'27-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	416,
	'Draperia',
	'Tim',
	'Mount Jenkins',
	'8-May-06');


INSERT INTO SIGHTINGS VALUES (
	417,
	'Sheltons violet',
	'Pete',
	'Piute Spring',
	'5-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	418,
	'California flannelbush',
	'Pete',
	'Scodie Mountains',
	'10-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	419,
	'Douglas dustymaiden',
	'Pete',
	'Chula Vista Campground',
	'9-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	420,
	'Ithuriels spear',
	'Pete',
	'Grouse Mountain',
	'4-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	421,
	'Butter and eggs',
	'Pete',
	'Scodie Mountains',
	'13-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	422,
	'Death camas',
	'Pete',
	'Don Levy Mine',
	'4-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	423,
	'Sheltons violet',
	'Brad',
	'Piute Spring',
	'5-Jun-06');


INSERT INTO SIGHTINGS VALUES (
	424,
	'California flannelbush',
	'Brad',
	'Scodie Mountains',
	'10-Jul-06');


INSERT INTO SIGHTINGS VALUES (
	425,
	'Douglas dustymaiden',
	'Brad',
	'Chula Vista Campground',
	'9-Jul-06');


