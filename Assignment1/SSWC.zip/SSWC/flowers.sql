INSERT INTO FLOWERS VALUES (
	0,
	'Triteleia',
	'laxa',
	'Ithuriels spear');


INSERT INTO FLOWERS VALUES (
	1,
	'Mimulus',
	'primuloides',
	'Primrose monkeyflower');


INSERT INTO FLOWERS VALUES (
	2,
	'Viola',
	'sheltonii',
	'Sheltons violet');


INSERT INTO FLOWERS VALUES (
	3,
	'Polemonium',
	'californicum',
	'Showy Jacobs ladder');


INSERT INTO FLOWERS VALUES (
	4,
	'Chaenactis',
	'douglasii',
	'Douglas dustymaiden');


INSERT INTO FLOWERS VALUES (
	5,
	'Castilleja',
	'lineariloba',
	'Pale owls clover');


INSERT INTO FLOWERS VALUES (
	6,
	'Zigadenus',
	'venenosus',
	'Death camas');


INSERT INTO FLOWERS VALUES (
	7,
	'Arabis',
	'platysperma',
	'Broad-seeded rock-cress');


INSERT INTO FLOWERS VALUES (
	8,
	'Calyptridium',
	'monospermum',
	'One-seeded pussy paws');


INSERT INTO FLOWERS VALUES (
	9,
	'Streptanthus',
	'diversifolius',
	'Varied-leaved jewelflower');


INSERT INTO FLOWERS VALUES (
	10,
	'Lilium',
	'pardalinum',
	'Leopard lily');


INSERT INTO FLOWERS VALUES (
	11,
	'Lomatium',
	'torreyi',
	'Torreys lomatium');


INSERT INTO FLOWERS VALUES (
	12,
	'Penstemon',
	'davidsonii',
	'Alpine penstemon');


INSERT INTO FLOWERS VALUES (
	13,
	'Lithophragma',
	'affine',
	'Woodland star');


INSERT INTO FLOWERS VALUES (
	14,
	'Sphenosciadium',
	'capitellatum',
	'Rangers buttons');


INSERT INTO FLOWERS VALUES (
	15,
	'Geranium',
	'molle',
	'Doves-foot geranium');


INSERT INTO FLOWERS VALUES (
	16,
	'Gilia',
	'mediomontana',
	'Globe gilia');


INSERT INTO FLOWERS VALUES (
	17,
	'Dudleya',
	'cymosa',
	'Canyon dudleya');


INSERT INTO FLOWERS VALUES (
	18,
	'Smilacina',
	'racemosa',
	'Large false Solomons seal');


INSERT INTO FLOWERS VALUES (
	19,
	'Asarum',
	'hartwegii',
	'Hartwegs wild ginger');


INSERT INTO FLOWERS VALUES (
	20,
	'Lewisia',
	'glandulosa',
	'Alpine lewisia');


INSERT INTO FLOWERS VALUES (
	21,
	'Heracleum',
	'lanatum',
	'Cow parsnip');


INSERT INTO FLOWERS VALUES (
	22,
	'Gilia',
	'leptalea',
	'Bridges gilia');


INSERT INTO FLOWERS VALUES (
	23,
	'Rumex',
	'paucifolia',
	'Alpine sheep sorrel');


INSERT INTO FLOWERS VALUES (
	24,
	'Juncus',
	'nevadensis',
	'Sierra Nevada rush');


INSERT INTO FLOWERS VALUES (
	25,
	'Carex',
	'limosa',
	'Mud sedge');


INSERT INTO FLOWERS VALUES (
	26,
	'Draperia',
	'systyla',
	'Draperia');


INSERT INTO FLOWERS VALUES (
	27,
	'Asclepias',
	'speciosa',
	'Showy milkweed');


INSERT INTO FLOWERS VALUES (
	28,
	'Triphysaria',
	'eriantha',
	'Butter and eggs');


INSERT INTO FLOWERS VALUES (
	29,
	'Parvisedum',
	'pumilum',
	'Sierra stonecrop');


INSERT INTO FLOWERS VALUES (
	30,
	'Eriogonum',
	'incanum',
	'Hoary buckwheat');


INSERT INTO FLOWERS VALUES (
	31,
	'Angelica',
	'lineariloba',
	'Sierra angelica');


INSERT INTO FLOWERS VALUES (
	32,
	'Sarcodes',
	'sanguinea',
	'Snow plant');


INSERT INTO FLOWERS VALUES (
	33,
	'Erigeron',
	'algidus',
	'Sierra daisy');


INSERT INTO FLOWERS VALUES (
	34,
	'Aquilegia',
	'pubescens',
	'Alpine columbine');


INSERT INTO FLOWERS VALUES (
	35,
	'Arenaria',
	'kingii',
	'Kings sandwort');


INSERT INTO FLOWERS VALUES (
	36,
	'Eriophyllum',
	'lanatum',
	'Woolly sunflower');


INSERT INTO FLOWERS VALUES (
	37,
	'Orthilia',
	'secunda',
	'One-sided wintergreen');


INSERT INTO FLOWERS VALUES (
	38,
	'Phyllodoce',
	'breweri',
	'Red mountain heather');


INSERT INTO FLOWERS VALUES (
	39,
	'Phlox',
	'condensata',
	'Condensed phlox');


INSERT INTO FLOWERS VALUES (
	40,
	'Clarkia',
	'rhomboidea',
	'Diamond clarkia');


INSERT INTO FLOWERS VALUES (
	41,
	'Lupinus',
	'polyphyllus',
	'Large-leaved lupine');


INSERT INTO FLOWERS VALUES (
	42,
	'Penstemon',
	'parvulus',
	'Purple penstemon');


INSERT INTO FLOWERS VALUES (
	43,
	'Epilobium',
	'angustifolium',
	'Fireweed');


INSERT INTO FLOWERS VALUES (
	44,
	'Viola',
	'quercetorum',
	'Oak violet');


INSERT INTO FLOWERS VALUES (
	45,
	'Senecio',
	'hydrophilus',
	'Water groundsel');


INSERT INTO FLOWERS VALUES (
	46,
	'Hypericum',
	'anagalloides',
	'Tinkers penny');


INSERT INTO FLOWERS VALUES (
	47,
	'Mimulus',
	'bicolor',
	'Yellow-and-white monkeyflower');


INSERT INTO FLOWERS VALUES (
	48,
	'Ligusticum',
	'grayi',
	'Lovage');


INSERT INTO FLOWERS VALUES (
	49,
	'Fremontodendron',
	'californicum',
	'California flannelbush');


